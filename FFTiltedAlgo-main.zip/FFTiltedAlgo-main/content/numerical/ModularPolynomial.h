/**
 * Author: Ormlis
 * Date: 2022-10-10
 * Description:
 */
struct Polynom {
    vector<int> coeffs;
    Polynom(int x = -1) {
        if (x != -1) coeffs = {x};
    }
    void init(int n) {
        coeffs.resize(n + 1);
    }
    void norm() {
        while (!coeffs.empty() && coeffs.back() == 0) coeffs.pop_back();
    }
    void modx(int k) {
        coeffs.resize(k);
    }
    void rev() {
        norm();
        reverse(all(coeffs));
    }
    int get(int x) {
        int ans = 0;
        int w = 1;
        for (auto &c : coeffs) {
            ans = add(ans, mul(w, c));
            w = mul(w, x);
        }
        return ans;
    }
};

Polynom operator+(const Polynom &a, const Polynom &b) {
    Polynom c;
    c.coeffs.resize(max(a.coeffs.size(), b.coeffs.size()));
    range(i, (int) a.coeffs.size()) c.coeffs[i] = add(c.coeffs[i], a.coeffs[i]);
    range(i, (int) b.coeffs.size()) c.coeffs[i] = add(c.coeffs[i], b.coeffs[i]);
    return c;
}

Polynom operator-(const Polynom &a, const Polynom &b) {
    Polynom c;
    c.coeffs.resize(max(a.coeffs.size(), b.coeffs.size()));
    range(i, (int) a.coeffs.size()) c.coeffs[i] = add(c.coeffs[i], a.coeffs[i]);
    range(i, (int) b.coeffs.size()) c.coeffs[i] = sub(c.coeffs[i], b.coeffs[i]);
    return c;
}

Polynom operator*(const Polynom &a, const Polynom &b) {
    Polynom c;
    c.coeffs = multiply(a.coeffs, b.coeffs);
    c.norm();
    return c;
}

Polynom inverse(const Polynom &A, int N) {
    Polynom P;
    assert(A.coeffs[0] != 0);
    P.coeffs = {rev(A.coeffs[0])};
    int sz = 1;
    while (sz < N) {
        sz <<= 1;
        auto A2 = A.coeffs;
        A2.resize(sz * 2);
        auto P2 = P.coeffs;
        range(i, sz) A2[i + sz] = 0;
        P2.resize(sz * 2);
        fft(A2);
        fft(P2);
        range(i, sz * 2) A2[i] = sub(2, mul(A2[i], P2[i]));
        range(i, sz * 2) P2[i] = mul(P2[i], A2[i]);
        fft(P2, true);
        P.coeffs = P2;
        P.modx(sz);
    }
    P.coeffs.resize(N);
    return P;
}

Polynom reverse(const Polynom &A, bool fixed = false) {
    auto B = A;
    if (!fixed) B.norm();
    reverse(all(B.coeffs));
    return B;
}

Polynom operator/(Polynom A, Polynom B) {
    A.norm();
    B.norm();
    int n = (int) A.coeffs.size();
    int m = (int) B.coeffs.size();
    auto rA = reverse(A);
    auto rB = reverse(B);
    auto cB = inverse(rB, n - m + 1);
    rA.modx(n - m + 1);
    auto rQ = rA * cB;
    rQ.modx(n - m + 1);
    auto Q = reverse(rQ, true);
    Q.norm();
    return Q;
}

pair<Polynom, Polynom> divmod(const Polynom &A, const Polynom &B) {
    auto Q = A / B;
    auto R = A - (B * Q);
    R.norm();
    return {Q, R};
}

Polynom operator%(const Polynom &A, const Polynom &B) {
    auto[Q, R] = divmod(A, B);
    return R;
}

Polynom derivatave(Polynom A) {
    A.norm();
    for (int i = 1; i < (int) A.coeffs.size(); ++i) {
        A.coeffs[i - 1] = mul(i, A.coeffs[i]);
    }
    if (!A.coeffs.empty()) A.coeffs.pop_back();
    return A;
}

Polynom integral(Polynom A) {
    A.norm();
    A.coeffs.push_back(0);
    for (int i = (int) A.coeffs.size() - 2; i >= 0; --i) {
        A.coeffs[i + 1] = mul(A.coeffs[i], rev(i + 1));
    }
    A.coeffs[0] = 0;
    A.norm();
    return A;
}

Polynom log(const Polynom &A, int N) {
    auto Ap = derivatave(A);
    auto Ar = inverse(A, N);
    auto B = Ap * Ar;
    B.norm();
    return integral(B);
}

Polynom powMod(Polynom A, ll b, const Polynom &M) {
    Polynom result(1);
    while (b) {
        if (b & 1) {
            result = (result * A) % M;
        }
        A = (A * A) % M;
        b >>= 1;
    }
    return result;
}
