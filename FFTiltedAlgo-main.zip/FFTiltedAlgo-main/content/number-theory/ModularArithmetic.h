/**
 * Author: Lukas Polacek
 * Date: 2009-09-28
 * License: CC0
 * Source: ormlis
 * Description: Operators for modular arithmetic. You need to set {\tt md} to
 * some number first and then you can use the code.
 */
#pragma once

const int md = 998244353; //1e9 + 7, 1e9 +
inline int add(const int &a, const int &b) {return a + b >= md ? a + b - md : a + b;}
inline int sub(const int &a, const int &b) {return a - b < 0 ? a - b + md : a - b;}
inline int mul(const int &a, const int &b) {return (1ll * a * b) % md;}
int pw(int a, ll b) {
    int res = 1;
    for(; b; b >>= 1, a = mul(a, a)) if (b & 1) res = mul(res, a);
    return res;
}
int rev(int a) {return pw(a, md - 2);}
const int maxN = 2e5 + 5;
int fact[maxN];
int rfact[maxN];
void initFact() {
    fact[0] = 1;
    for (int i = 1; i < maxN; ++i) fact[i] = mul(fact[i - 1], i);
    rfact[maxN - 1] = rev(fact[maxN - 1]);
    for (int i = maxN - 1; i >= 1; --i) {
        rfact[i - 1] = mul(rfact[i], i);
    }
}
int C(int n, int k) {
    if (k < 0 || n < k) return 0;
    return mul(fact[n], mul(rfact[k], rfact[n - k]));
}