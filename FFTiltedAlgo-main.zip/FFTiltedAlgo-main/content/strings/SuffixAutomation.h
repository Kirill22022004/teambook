/**
 * Author: Ormlis
 * Date: 2022
 * License: Unknown
 * Source: own
 * Description:
 * Time: O(n \log n)
 * Status: unknown
 */
struct suf_auto {
    struct Node {
        int to[26]{};
        int p = -1;
        int link = -1;
    };
    vector<Node> t;
    int last = 0;
    void build() {
        t.emplace_back();
    }
    void add(char ch, int a = -1) {
        ch -= 'a';
        if (a == -1) a = last;
        int b = t.size();
        t.emplace_back();
        t[b].p = a;
        t[b].link = 0;
        last = b;
        for (; a != -1; a = t[a].link) {
            if (!t[a].to[ch]) {
                t[a].to[ch] = b;
                continue;
            }
            int c = t[a].to[ch];
            if (t[c].p == a) {
                t[b].link = c;
                break;
            }
            int d = t.size();
            t.emplace_back();
            t[d] = t[c];
            t[d].p = a;
            t[c].link = t[b].link = d;
            for (; a != -1 && t[a].to[ch] == c; a = t[a].link) {
                t[a].to[ch] = d;
            }
            break;
        }
    }
};