/**
 * Author: Fedor Romashov
 * Description: Stress test
 */

import os

os.system("g++ smart.cpp -o smart")
os.system("g++ stupid.cpp -o stupid")

i = 0
while True:
    os.system(f"python3 gen.py {i} > test.txt")

    os.system(".\smart < test.txt > smart.out")
    os.system(".\stupid < test.txt > stupid.out")

    ans1 = open("smart.out").readlines()
    ans2 = open("stupid.out").readlines()
    if ans1 != ans2:
        print(f"WA {i}")
        exit(0)
    i += 1