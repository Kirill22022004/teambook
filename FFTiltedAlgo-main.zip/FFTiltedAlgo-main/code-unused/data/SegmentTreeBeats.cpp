struct segment_tree_beats {
    struct Node {
        ll sum = 0;
        int mn = 0, s_mn = INFi;
        int cnt = 0;
        int upd = 0;
        int updsum = 0;

        void combine(const Node &a, const Node &b) {
            mn = min(a.mn, b.mn);
            cnt = a.cnt + b.cnt;
            s_mn = INFi;
            if (b.mn != mn) {
                cnt -= b.cnt;
                s_mn = b.mn;
            } else if (a.mn != mn) {
                s_mn = a.mn;
                cnt -= a.cnt;
            }
            s_mn = min(s_mn, min(a.s_mn, b.s_mn));
            sum = a.sum + b.sum;
        }

        void check(int &val) {
            if (mn >= val) return;
            sum += 1ll * cnt * (val - mn);
            mn = val;
            upd = val;
        }

        void checkadd(int &val, int l, int r) {
            mn += val;
            s_mn += val;
            updsum += val;
            upd += val;
            sum += 1ll * val * (r - l);
        }
    };

    void push(int v, int l, int r) {
        tree[v << 1].checkadd(tree[v].updsum, l, (l + r) >> 1);
        tree[(v << 1) + 1].checkadd(tree[v].updsum, (l + r) >> 1, r);
        tree[v << 1].check(tree[v].upd);
        tree[(v << 1) + 1].check(tree[v].upd);
        tree[v].updsum = 0;
    }

    vector<Node> tree{};
    int n{};

    void build(int k) {
        n = k;
        tree.resize(n * 4);
        make(1, 0, n);
    }

    void make(int v, int l, int r) {
        tree[v].cnt = r - l;
        if (l + 1 == r) return;
        make(v << 1, l, (l + r) >> 1);
        make((v << 1) + 1, (l + r) >> 1, r);
    }

    void updsum(int v, int l, int r, int &lq, int &rq, int &val) {
        if (lq <= l && r <= rq) {
            tree[v].checkadd(val, l, r);
            return;
        }
        push(v, l, r);
        int mid = (l + r) >> 1;
        if (mid > lq) updsum(v << 1, l, mid, lq, rq, val);
        if (rq > mid) updsum((v << 1) + 1, mid, r, lq, rq, val);
        tree[v].combine(tree[v << 1], tree[(v << 1) + 1]);
    }

    void updmax(int v, int l, int r, int &lq, int &rq, int &val) {
        if (tree[v].mn >= val) return;
        if (lq <= l && r <= rq && tree[v].s_mn > val) {
            tree[v].check(val);
            return;
        }
        push(v, l, r);
        int mid = (l + r) >> 1;
        if (mid > lq) updmax(v << 1, l, mid, lq, rq, val);
        if (rq > mid) updmax((v << 1) + 1, mid, r, lq, rq, val);
        tree[v].combine(tree[v << 1], tree[(v << 1) + 1]);
    }

    ll get(int v, int l, int r, int &lq, int &rq) {
        if (lq <= l && r <= rq) {
            return tree[v].sum;
        }
        push(v, l, r);
        int mid = (l + r) >> 1;
        ll res = 0;
        if (mid > lq) res += get(v << 1, l, mid, lq, rq);
        if (rq > mid) res += get((v << 1) + 1, mid, r, lq, rq);
        return res;
    }

    ll get(int lq, int rq) {
        auto res = get(1, 0, n, lq, rq);
        return res;
    }

    void updmax(int lq, int rq, int val) {
        updmax(1, 0, n, lq, rq, val);
    }

    void updsum(int lq, int rq, int val) {
        updsum(1, 0, n, lq, rq, val);
    }
};