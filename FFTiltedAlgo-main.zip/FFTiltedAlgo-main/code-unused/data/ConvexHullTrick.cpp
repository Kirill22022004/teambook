struct convex_hull_trick {
    struct Line {
        ll k, b;

        ll get(ll x) {
            return k * x + b;
        }
    };

    vector <ll> xx;
    vector <Line> lines;

    ll intersect(Line &a, Line &b) {
        if (a.k == b.k) {
            if (a.b < b.b) return -INF;
            return INF;
        }
        // x = (a.b - b.b) / (b.k - a.k)
        if (a.b >= b.b) {
            return (a.b - b.b + (b.k - a.k - 1)) / (b.k - a.k);
        } else {
            return (a.b - b.b) / (b.k - a.k);
        }
    }

    void add(ll k, ll b) {
        Line A = {k, b};
        while (!lines.empty() && intersect(A, lines.back()) <= xx.back()) {
            xx.pop_back();
            lines.pop_back();
        }
        if (lines.empty()) {
            xx.push_back(-INF);
        } else {
            xx.push_back(intersect(A, lines.back()));
        }
        lines.push_back(A);
    }

    ll get(ll x) {
        int i = upper_bound(all(xx), x) - xx.begin();
        return lines[i - 1].get(x);
    }
};