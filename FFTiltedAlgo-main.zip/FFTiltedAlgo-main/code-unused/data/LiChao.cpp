struct Line {
    ll k = 0, b = -INF;

    ll get(ll x) {
        return k * x + b;
    }
};

// max
struct LiChao {
    int n{};
    vector<Line> tree{};
    vector<ll> x{};

    void build(int k, vector<ll> &xx) {
        n = k;
        tree.resize(n * 4);
        x = xx;
    }


    void upd(int v, int l, int r, Line L) {
        int m = (r + l) >> 1;
        if (tree[v].get(x[m]) < L.get(x[m])) swap(tree[v], L);
        if (l + 1 == r) return;
        if (tree[v].get(x[l]) > L.get(x[l])) {
            upd(v << 1 | 1, m, r, L);
        } else {
            upd(v << 1, l, m, L);
        }
    }

    ll get(int v, int l, int r, int i) {
        if (l + 1 == r) return tree[v].get(x[i]);
        int m = (r + l) >> 1;
        if (i < m) return max(tree[v].get(x[i]), get(v << 1, l, m, i));
        else return max(tree[v].get(x[i]), get(v << 1 | 1, m, r, i));
    }

    void upd(ll k, ll b) {
        Line L = {k, b};
        upd(1, 0, n, L);
    }

    ll get(ll xx) {
        int i = lower_bound(all(x), xx) - x.begin();
        return get(1, 0, n, i);
    }
};