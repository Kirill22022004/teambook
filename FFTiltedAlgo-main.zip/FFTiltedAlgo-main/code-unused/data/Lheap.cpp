struct Lheap {
    int x;
    int s;
    Lheap *l, *r;

    Lheap() : x(0), s(0), l(nullptr), r(nullptr) {}
};

Lheap *copy(Lheap *a) {
    Lheap *c = new Lheap();
    c->x = a->x;
    c->s = a->s;
    c->l = a->l;
    c->r = a->r;
    return c;
}

int get_s(Lheap *a) {
    if (!a) return 0;
    return a->s;
}

void upd(Lheap *a) {
    if (!a) return;
    a->s = get_s(a->r) + 1;
}

Lheap *merge(Lheap *a, Lheap *b) {
    if (!a) return b;
    if (!b) return a;
    if (a->x > b->x) swap(a, b);
    a = copy(a);
    a->r = merge(a->r, b);
    if (get_s(a->r) > get_s(a->l)) swap(a->l, a->r);
    upd(a);
    return a;
}