struct FSegTree {
    struct Node {
        int value;

        Node(int _val = INFi) : value(_val) {}

        void combine(const Node &a, const Node &b) {
            value = min(a.value, b.value);
        }

        void apply(int x) {
            value = x;
        }
    };

    Node combine(const Node &a, const Node &b) {
        Node res;
        res.combine(a, b);
        return res;
    }

    vector<Node> t;
    int n;

    void build(int k) {
        n = k;
        t.resize(n * 2);
    }

    template<typename T>
    void build(vector<T> &v) {
        n = v.size();
        t.resize(n * 2);
        range(i, n) t[i + n].apply(v[i]);
        for (int i = n - 1; i >= 1; --i) t[i].combine(t[i << 1], t[i << 1 | 1]);
    }

    void upd(int i, int x) {
        t[i += n].apply(x)
        for (i >>= 1; i >= 1; i >>= 1) t[i].combine(t[i << 1], t[i << 1 | 1]);
    }

    // [l, r)
    Node get(int l, int r) {
        Node resultL, resultR;
        for (l += n, r += n; l < r; l >>= 1, r >>= 1) {
            if (l & 1) resultL = combine(resultL, t[l++]);
            if (r & 1) resultR = combine(t[--r], resultR);
        }
        return combine(resultL, resultR);
    }
};