struct min_cost_max_flow {
    struct Edge {
        int u, c, f, w;
    };
    vector<Edge> edges;
    vector<vector<int>> g;
    vector<int> p, dist, pv;
    int s, t, n;

    void build(int k) {
        n = k;
        g.resize(n);
        p.resize(n);
        dist.resize(n);
        pv.resize(n);
    }

    void add_edge(int v, int u, int c, int w) {
        int i = (int) edges.size();
        g[v].push_back(i);
        g[u].push_back(i + 1);
        edges.push_back({u, c, 0, w});
        edges.push_back({v, 0, 0, -w});
    }

    void set_s(int v) {
        s = v;
    }

    void set_t(int v) {
        t = v;
    }

    vector<int> used, ts;

    void dfs_ts(int v) {
        used[v] = 1;
        for (auto &i : g[v]) {
            Edge &e = edges[i];
            if (e.f == e.c) continue;
            if (used[e.u]) continue;
            dfs_ts(e.u);
        }
        ts.push_back(v);
    }


    void FordBellman() {
        used.resize(n);
        dfs_ts(s);
        reverse(all(ts));
        for (auto &v : ts) {
            for (auto &i : g[v]) {
                Edge &e = edges[i];
                if (e.f == e.c) continue;
                p[e.u] = min(p[e.u], p[v] + e.w);
            }
        }
    }

    bool dijkstra(bool need_upd = false) {
        dist.assign(n, INFi);
        used.assign(n, 0);
        dist[s] = 0;
        range(_, n)
        {
            int d = INFi;
            range(i, n)
            if (!used[i] && dist[i] < d) d = dist[i];
            int v = 0;
            range(i, n)
            if (dist[i] == d && !used[i]) v = i;
            if (d == INFi) break;
            used[v] = 1;
            for (auto &i : g[v]) {
                if (edges[i].f == edges[i].c) continue;
                int u = edges[i].u;
                int w = edges[i].w + p[v] - p[u];
                if (dist[u] > d + w) {
                    dist[u] = d + w;
                    pv[u] = i;
                }
            }
        }
        if (need_upd) {
            range(i, n)
            p[i] += dist[i];
        }
        return dist[t] != INFi;
    }

    // max-flow -> can change to k-flow
    ll find_min_cost() {
        FordBellman();
        ll res = 0;
        while (dijkstra()) {
            int v = t;
            int mf = INFi;
            while (v != s) {
                mf = min(mf, edges[pv[v]].c - edges[pv[v]].f);
                v = edges[pv[v] ^ 1].u;
            }
            v = t;
            while (v != s) {
                edges[pv[v]].f += mf;
                edges[pv[v] ^ 1].f -= mf;
                res += 1ll * edges[pv[v]].w * mf;
                v = edges[pv[v] ^ 1].u;
            }
            dijkstra(true);
        }
        return res;
    }
};