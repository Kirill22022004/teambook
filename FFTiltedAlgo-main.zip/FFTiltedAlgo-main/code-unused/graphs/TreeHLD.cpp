SegmentTree ST;
vector<int> g[maxN];
int tin[maxN], tout[maxN];
int c[maxN];
int sz[maxN];
int head[maxN];
int pr[maxN];
vector<int> a;
int T = 0;

void dfs_sz(int v) {
    sz[v] = 1;
    for (auto &u : g[v]) {
        dfs_sz(u);
        sz[v] += sz[u];
    }
    sort(all(g[v]), [&](const int i, const int j) {
        return sz[i] > sz[j];
    });
}

void dfs(int v) {
    tin[v] = T++;
    a.push_back(c[v]);
    bool f = false;
    for (auto &u : g[v]) {
        if (!f) head[u] = head[v], f = true;
        else head[u] = u;
        pr[u] = v;
        dfs(u);
    }
    tout[v] = T;
}

ll get(int v) {
    ll res = ST.get(tin[v] + 1, tout[v]);
    while (v != -1) {
        res += ST.get(tin[head[v]], tin[v] + 1);
        v = pr[head[v]];
    }
    return res;
}

void upd(int v, ll x) {
    ST.upd(tin[v] + 1, tout[v], x);
    while (v != -1) {
        ST.upd(tin[head[v]], tin[v] + 1, x);
        v = pr[head[v]];
    }
}