// Need Polynom
vector<int> BerlyKamp(const vector<int> &a) {
    int N = a.size();
    assert(N >= 1);
    vector<int> Rn, Rm;
    int m = -1, dm = -1;
    Rn = {1};
    for (int n = 1; n < N; ++n) {
        if (m == -1) {
            if (a[n] == 0) continue;
            Rm = {1};
            Rn.resize(n + 1);
            m = n;
            continue;
        }
        int dn = 0;
        range(j, (int) Rn.size()) {
            dn = add(dn, mul(a[n - j], Rn[j]));
        }
        if (dn == 0) continue;
        int k = mul(dn, rev(dm));
        int sz = max((int) Rn.size(), (int) Rm.size() + (n - m));
        auto kek = Rn;
        Rn.resize(sz);
        range(j, (int) Rm.size()) {
            Rn[j + n - m] = sub(Rn[j + n - m], mul(k, Rm[j]));
        }
        if (Rn.size() > Rm.size()) {
            dm = dn;
            m = n;
            Rm = kek;
        }
    }
    vector<int> result;
    for (int i = 1; i < (int) Rn.size(); ++i) {
        result.push_back(sub(0, Rn[i]));
    }
    return result;
}

int solve_recurent(int k, ll n, vector<int> A, vector<int> C) {
    Polynom M, P;
    P.init(1);
    P.coeffs[1] = 1;
    M.init(k);
    M.coeffs[k] = 1;
    for (int i = k - 1; i >= 0; --i) {
        M.coeffs[i] = sub(0, C[k - 1 - i]);
    }
    auto res = powMod(P, n - 1, M);
    int ans = 0;
    res.coeffs.resize(k);
    range(i, k) {
        ans = add(ans, mul(A[i], res.coeffs[i]));
    }
    return ans;
}