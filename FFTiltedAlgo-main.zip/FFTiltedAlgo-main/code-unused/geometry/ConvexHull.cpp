vector<pt> ConvexHull(vector<pt> pts) {
    int min_idx = min_element(all(pts)) - pts.begin();
    swap(pts[0], pts[min_idx]);

    sort(pts.begin() + 1, pts.end(), [&](const pt &a, const pt &b) {
        if ((a - pts[0]) * (b - pts[0])) return (a - pts[0]) * (b - pts[0]) > 0;
        return (a - pts[0]) % (a - pts[0]) < (b - pts[0]) % (b - pts[0]);
    });

    vector<pt> convex_hull = {pts[0]};
    int sz = 0;
    for (int i = 1; i < (int) pts.size(); ++i) {
        while (sz && (convex_hull[sz] - convex_hull[sz - 1]) * (pts[i] - convex_hull[sz]) <= 0) {
            convex_hull.pop_back();
            --sz;
        }
        convex_hull.push_back(pts[i]);
        ++sz;
    }

    return convex_hull;
}