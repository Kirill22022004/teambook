struct pt {
    ll x = 0, y = 0;
};

bool operator<(const pt &a, const pt &b) {
    return tie(a.x, a.y) < tie(b.x, b.y);
}

bool operator==(const pt &a, const pt &b) {
    return tie(a.x, a.y) == tie(b.x, b.y);
}

pt operator*(const pt &a, const ll &b) {
    return {a.x * b, a.y * b};
}

pt operator+(const pt &a, const pt &b) {
    return {a.x + b.x, a.y + b.y};
}

pt operator-(const pt &a, const pt &b) {
    return {a.x - b.x, a.y - b.y};
}

//векторное - площадь
ll operator*(const pt &a, const pt &b) {
    return a.x * b.y - a.y * b.x;
}

//скалярное
ll operator%(const pt &a, const pt &b) {
    return a.x * b.x + a.y * b.y;
}