vector<int> Pfunc(const vector<int> &s) {
    int n = s.size();
    vector<int> p(n);
    for (int i = 1; i < n; ++i) {
        p[i] = p[i - 1];
        while (p[i] && s[p[i]] != s[i]) {
            p[i] = p[p[i] - 1];
        }
        if (s[p[i]] == s[i]) p[i]++;
    }
    return p;
}

vector<int> Zfunc(const vector<Int> &s) {
    int n = s.size();
    vector<int> z(n);
    int l = 0, r = 0;
    for (int i = 1; i < n; ++i) {
        if (i < r) z[i] = min(z[i - l], r - i);
        while (i + z[i] < n && s[i + z[i]] == s[z[i]]) z[i]++;
        if (i + z[i] > r) {
            l = i;
            r = i + z[i];
        }
    }
    return z;
}