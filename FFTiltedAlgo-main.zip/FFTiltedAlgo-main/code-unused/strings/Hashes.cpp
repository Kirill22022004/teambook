const int m;
mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

int P;

void gen() {
    while(P < 1000) P = rng() % md;
}

struct hash_struct {
    vector<int> hashes{};
    vector<int> sP{};

    static int madd(int a, int b) {
        if (a + b >= m) {
            return a + b - m;
        }
        return a + b;
    }

    static int msub(int a, int b) {
        if (a - b < 0) {
            return a - b + m;
        }
        return a - b;
    }

    static int mul(int a, int b) {
        return (1ll * a * b) % m;
    }

    void build(string &s) {
        if (s.empty()) return;
        hashes.resize(s.size());
        sP.resize(s.size());
        sP[0] = 1;
        hashes[0] = s[0];
        for (int i = 1; i < (int) s.size(); ++i) {
            sP[i] = mul(sP[i - 1], P);
            hashes[i] = madd(mul(hashes[i - 1], P), s[i]);
        }
    }

    // [l; r]
    int get(int l, int r) {
        if (l == 0) {
            return hashes[r];
        }
        return msub(hashes[r], mul(hashes[l - 1], sP[r - l + 1]));
    }

    // [l1; r1] == [l2; r2]
    bool check(int l1, int r1, int l2, int r2) {
        return get(l1, r1) == get(l2, r2);
    }
};